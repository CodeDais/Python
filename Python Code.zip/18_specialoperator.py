# a=150
# b=150
# print(a is b)
# print(id(a))
# print(id(b))


# a=150
# b=160
# print(a is b)
# print(id(a))
# print(id(b))


# a=150
# b=555
# print(a is not b)


# name='surendra'
# name1='surendra'
# print(name is name1)


# a=True
# b=True
# print(a is b)



# in not in 


name="surendra kumar panda"
# print('k' in name)
# # print('kk' in name)
# print('kumar' in name)
# print(' ' in name)
# print('z' not in name)

# list1=['rahul','priyanka','jack','john']

# print('rahul' in list1)
# print('priyanka' not in list1)