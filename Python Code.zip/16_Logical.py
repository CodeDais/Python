# print(True and True)
# print(True and False)
# print(False and True)
# print(False and False)


# print(True or True)
# print(True or False)
# print(False or True)
# print(False or False)

# print(not True)
# print(not False)



# non-boolean type 
# print(10 and 15)
# print(0 and 15)

# print(10 or 15)
# print(0 or 15)

# print(not 'surendra')

# print('surendra' and 'surendrapanda')
# print('surendra' or 'surendrapanda')

print(not '')