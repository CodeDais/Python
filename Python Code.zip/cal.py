a=100
b=200

def add(x,y):
        print(f' i m from cal module add is {x+y}')
        

def sub(x,y):
        print(f' i m from cal module sub is {x-y}')