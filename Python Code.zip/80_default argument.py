# def fun(name):
#     print(f'hi {name} good morning')


# fun('surendra')


# def fun(name):
#     print(f'hi {name} good morning')


# fun()

# default argumnet

# def fun(name='unknown'):
#     print(f'hi {name} good morning')


# fun()


# def fun(name='unknown'):
#     print(f'hi {name} good morning')


# fun('surendra')

# postional and default argument

# def msg(bf, gf='u dont have gf'):
#     print(f'hi {bf}  {gf}')


# # msg('rahul', 'zini')
# msg('surendra')


# def msg(bf='u dont have bf', gf='u dont have gf'):
#     print(f'hi {bf}  {gf}')


# # msg('rahul', 'zini')
# msg('zini')


# def msg(bf='u dont have bf', gf='u dont have gf'):
#     print(f'hi {bf}  {gf}')


# # msg('rahul', 'zini')
# msg(gf='zini')


# def msg(bf='u dont have bf', gf='u dont have gf'):
#     print(f'hi {bf}  {gf}')


# # msg('rahul', 'zini')
# msg(gf='zini', bf='rahul')


# def msg(bf='u dont have bf', gf='u dont have gf'):
#     print(f'hi {bf}  {gf}')


# # msg('rahul', 'zini')
# msg(gf='zini', bf='rahul')

# def student(name,id,email='no',mark):
#     print('name is  ',name)
#     print('id  is ',id)
#     print('email  is ', email)
#     print('mark  is ', mark)


# student('surendra',102423,55)


# def student(name, id, mark, email='no'):
#     print('name is  ', name)
#     print('id  is ', id)
#     print('email  is ', email)
#     print('mark  is ', mark)


# student('surendra', 102423, 55)


# def student(name, id, mark, email='no'):
#     print('name is  ', name)
#     print('id  is ', id)
#     print('email  is ', email)
#     print('mark  is ', mark)


# student('surendra', 102423, 55, 'surendra@gmail.com')


# def student(name, id, mark, email='no', addr='no'):
#     print('name is  ', name)
#     print('id  is ', id)
#     print('email  is ', email)
#     print('mark  is ', mark)
#     print('addr is ', addr)


# student('surendra', 102423, 55, 'surendra@gmail.com')


def student(name, id, mark, email='no', addr='no'):
    print('name is  ', name)
    print('id  is ', id)
    print('email  is ', email)
    print('mark  is ', mark)
    print('addr is ', addr)


student('surendra', 102423, 55, addr='paradeep')
