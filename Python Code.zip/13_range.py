# r=range(20)
# for i in r:
#     print(i)

# r=range(1,20)
# for i in r:
#     print(i)


# r=range(1,20,2)
# for i in r:
#     print(i)

r=range(10)
# print(r[0])
# r[5]=20
# print(r[5])
print(r[20])