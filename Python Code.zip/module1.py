a=1000
b=2000
def add(x,y):
    '''this is function will take 2 argumnet and it will add them'''
    print(x+y)
