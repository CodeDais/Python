i=1
result=0
while i<=10:
    result=result+i
    i=i+1

print(result)