a=int(nput('enter the value of a '))
b=int(nput('enter the value of b '))
c=int(nput('enter the value of c '))

if a>b and a>c:
    print('a is greater')
elif b>c:
    print('b is greater')
else:
    print('c is greater')