# s = 'mamamij'
# d = {}
# for i in s:
#     d[i] = d.get(i, 0)+1

# print(d)


# s = 'mamamij'
# d = {}
# for i in s:
#     d[i] = d.get(i, 0)+1

# print(d)
#


# s = 'mamamij'
# d = {}
# for i in s:
#     d[i] = d.get(i, 0)+1

# print(d)

# for i, j in d.items():
#     print(f'{i} is present {j} times')
