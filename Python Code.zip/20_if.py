# input a student mark and check the result 
# pass or fail 
# mark>=33 pass fail 

# mark=int(input('enter your mark'))

# if mark>=33:
#     print('cong.. pass')

# if mark<33:
#     print('sry .. fail')


# if else 

# mark=int(input('enter your mark'))

# if mark>=33:
#     print('cong.. pass')
# else:
#     print('sry .. fail')



# if elif else 

# num=int(input('enter a number in between 1-5'))

# if num==1:
#     print('a')
# elif num==2:
#     print('b')
# elif num==3:
#     print('c')
# elif num==4:
#     print('d')
# elif num==5:
#     print('e')
# else:
#     print('invalid option plz chose valid option')