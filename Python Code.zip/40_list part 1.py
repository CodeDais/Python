# l = [10, 20, 30, 'surendra', 'priyanka', 23, 44.678]
# print(l)


# l = [10, 20, 30, 'surendra', 'priyanka', 23, 44.678]
# print(l[-4])


# l = eval(input("enter a list"))
# print(l)


# l = eval(input("enter a list"))
# print(l)


# l = list(range(10, 21))
# print(l)


# l = list(range(21))
# print(l)


# l = [23, {"x": "surendra"}, list((10, 20, 30))]
# print(l)


# msg = "welcome to python class"
# l = msg.split()
# print(l)


# msg = "welc-ome-t-o py-tho-n cl-ass"
# l = msg.split('-')
# print(l)


# msg = "welc-ome-t-o py-tho-n cl-ass"
# l = msg.split('o')
# print(l)


# l = [10, 20, 30, 40, 50]
# print(l[90])


# l = [10, 20, 30, 40, 50]
# print(l[2::2])
# print(l[::])