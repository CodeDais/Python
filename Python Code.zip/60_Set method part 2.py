# union()
# A = {23, 33, 43, 53, 63}
# B = {11, 12, 13, 23, 53}
# print(A.union(B))
# print(A | B)


# instersection()
# A = {23, 33, 43, 53, 63}
# B = {11, 12, 13, 23, 53}
# print(A.intersection(B))
# print(A & B)


# difference()
# A = {23, 33, 43, 53, 63}
# B = {11, 12, 13, 23, 53}
# print(A.difference(B))
# print(A - B)


# symmetric_difference()
# A = {23, 33, 43, 53, 63}
# B = {11, 12, 13, 23, 53}
# print(A.symmetric_difference(B))
# print(A ^ B)


# subset
# A = {1, 2, 3, 4, 5, 6, 7, 8, 9}
# B = {3, 4, 5, 6}
# # print(B.issubset(A))
# print(A.issubset(B))


# superset
# A = {1, 2, 3, 4, 5, 6, 7, 8, 9}
# B = {3, 4, 5, 6}
# print(A.issuperset(B))
# print(B.issuperset(A))


# disjoint
# A = {1, 2, 3, 4, 5, 6, 7, 8, 9}
# B = {11, 12, 13}
# print(A.isdisjoint(B))
# print(B.isdisjoint(A))
