a=20
b=2
print(a+b)
print(a-b)
print(a*b)
print(a/b)
print(a%b)
print(a**b)
print(a//b)












# a=50
# b=2
# print(a/b)
# print(a//b)



# a=50.0
# b=2
# print(a/b)
# print(a//b)


# name='surendra'
# print(name+25)


# name='surendra'
# print(name+'25')


# name='surendra'
# print(name*3)


# name='surendra'
# print(name*3.3)



# a=100
# b=0
# print(a/b)


# a,b,c,d,e,f,g,h=1,2,3,4,5,2,6,7
# result=(a+b)*(c+d)*e**f//g+h
# print(result)