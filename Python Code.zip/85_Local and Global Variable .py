# Local variables

# def fun1():
#     a = 23  # local variable
#     print(a)


# def fun2():
#     print(a)


# fun1()
# fun2()


# Global Variables

# a = 23  # global variable

# def fun():
#     print(a)

# def fun2():
#     print(a)

# fun()
# fun2()


# a = 23  # global variable


# def fun():

#     print(a)


# def fun2():
#     print(a)


# fun()
# fun2()
# print(a)
