# l=[i for i in range(11)]
# print(l)

# l = [i*i for i in range(11)]
# print(l)


# l = [i**i for i in range(11)]
# print(l)


# l = [i+10 for i in range(11)]
# print(l)

# with uisng LC
# l = [i for i in range(1, 21) if i % 2 == 0]
# print(l)

# Without uisng LC
# l = []
# for i in range(1, 21):
#     if i % 2 == 0:
#         l.append(i)

# print(l)


# name=['surendra','priyanka','rahul','zini']
# excepted output : ['s','p','r','z']

# names=['surendra','priyanka','rahul','zini']
# l=[i[0] for i in names]
# print(l)

# names = ['surendra', 'priyanka', 'rahul', 'zini']
# l = [i[0:4] for i in names]
# print(l)

# create a new list by add the element wich is containg letter a
# names = ['surendra', 'priyanka', 'rahul', 'zini']

# l = [i for i in names if 'a' in i]
# print(l)


#
# names = ['surendra', 'priyanka', 'rahul', 'zini']

# l = [i if i != 'priyanka' else 'hello' for i in names]
# print(l)


# create a list from tuple
# t = (10, 20, 30, 40, 50)
# l = [i for i in t]
# print(l)


# t = (10, 20, 30, 40, 50)
# l = [i for i in t if i % 6 == 0]
# print(l)

#  create a list from string
# name="surendra"
# l=[i for i in name]
# print(l)

# # creation of matrix using list com..
# m = [[j for j in range(3)] for i in range(3)]
# print(m)



# m = [[i for j in range(5)] for i in range(5)]
# print(m)


# m = [[i*j for j in range(5)] for i in range(5)]
# print(m)

