# del None

# a=100
# print(a)

# del a

# print(a)

# s = "surendra"
# print(s)
# del s
# print(s)


# s = "surendra"
# print(s)
# del s[0]
# print(s)


# l = [10, 20, 30, 40, 50]
# print(l)
# del l
# print(l)


# l = [10, 20, 30, 40, 50]
# print(l)
# del l[2]
# print(l)


# s = "surendra"
# print(s)
# del s
# print(s)
# s = "priyanka"
# print(s)


#   None

# s = "surendra"
# print(s)
# s = None
# print(s)
# s = "priyanka"
# print(s)
