# other to int 
# float 
# a=int(55.00)
# print(a)

# complex
# a=int(100+20j)
# print(a)

# bool
# a=int(True)
# print(a)

# a=int(False)
# print(a)

# a=int(True+True+True)
# print(a)

# a=int(True+True-False) # 1+1-0 = 2
# print(a)


# str

# a=int('hello')
# print(a)


# a=int('100')
# print(a)

# a=int('100.200')
# print(a)

# a=int('0b10101')
# print(a)

# other to float 
#int 
# a=float(100)
# print(a)


#complex
# a=float(100+20j)
# print(a)


#bool

# a=float(True)
# print(a)


# a=float(True+True)
# print(a)

#str

# a=float('hello')
# print(a)

# a=float('250')
# print(a)

# a=float('250.55')
# print(a)

# other to comlpex
# int 

# a=complex(10)
# print(a)

# float 
# a=complex(10.56)
# print(a)

# bool
# a=complex(True+True)
# print(a)

# str
# a=complex('hello')
# print(a)

# a=complex('100.56')
# print(a)

# a=complex('100')
# print(a)

# a=complex(10,2)
# print(a)

# a=complex(12,55)
# print(a)


# a=complex(-12,55)
# print(a)

# a=complex(-12,-55)
# print(a)

# a=complex(True,False)
# print(a)

# a=complex(True,500)
# print(a)

# other to bool 
#int 
# a=bool(1)
# print(a)

# a=bool(15) # non-zero value means True
# print(a)

# a=bool(0)
# print(a)

# a=bool(0)
# print(a)




#float

# a=bool(10.0)
# print(a)

# a=bool(0.0)
# print(a)

# a=bool(0.1)
# print(a)




#complex

# a=bool(10+2j)
# print(a)

# a=bool(10-2j)
# print(a)
#str

# a=bool('10')
# print(a)

# a=bool('hello')
# print(a)


# a=bool('')
# print(a)


# a=bool('True')
# print(a)


#other to str 
#int 
# a=str(100)
# print(a)
# print(type(a))




#float
# a=str(100.55)
# print(a)


#complex
# a=str(10+5j)
# print(a)
# print(type(a))
#bool

# a=str(True)  
# print(a)
# print(type(a))


# a=str(False)  
# print(a)
# print(type(a))

