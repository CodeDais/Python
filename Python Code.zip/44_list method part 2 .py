# l = [10, 20, 30, 40, 50]
# s = [100, 200, 300]
# l.extend(s)
# print(l)


# l = [2, 1, 4, 3, 6, 8, 5]
# l.sort()
# print(l)

# l = [2, 1, 4, 3, 6, 8, 5]
# l.sort(reverse=True)
# print(l)


# l = ['surendra', 'rahul', 23, 33, 43, 54]
# l.sort()
# print(l)


# l = [2, 1, 4, 3, 6, 8, 5]
# print(l)
# l.clear()
# print(l)


# l = [2, 1, 4, 3, 6, 8, 5]
# print(l)
# del l
# print(l)


# l=[10,20,30,40,50]
# s=l.copy()   #cloning

# print(l)
# print(s)

# print(id(l))#2349066889600
# print(id(s))#2349066842560

# s[2]=9999


# print(l)
# print(s)


l = [10, 20, 30, 40, 50]
s = l  

print(l)
print(s)

print(id(l))  
print(id(s))  

s[2] = 9999

print(l)
print(s)


