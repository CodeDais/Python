# l = [23, 33, 43, 53, 64]
# print(l)
# l.append(678)
# print(l)
# l.append(789)
# print(l)


# # create a list by adding 20 0s
# l = []
# for i in range(20):
#     l.append(0)

# print(l)


# create a list by adding 0 to 20
# l = []
# for i in range(21):
#     l.append(i)

# print(l)


# insert()

# l = [23, 33, 43, 53, 64]
# print(l)
# l.insert(2, 789)
# print(l)


# l = [23, 33, 43, 53, 64]
# print(l)
# l.insert(20, 789)
# print(l)

# print(l.index(789))


# l = [23, 33, 43, 53, 64, 23, 23]
# print(l.count(23))


# l = [23, 33, 43, 53, 64, 23, 23]
# print(l.count(8878))


# l = [23, 33, 43, 53, 64, 23, 23]
# print(l.index(23))
# print(l.index(78999))


# l = [23, 33, 43, 53, 64, 23, 23]
# l.remove(23)
# print(l)

# l = [23, 33, 43, 53, 64, 23, 23]
# l.remove(7894)
# print(l)


# l = [23, 33, 43, 53, 64, 23, 23]
# l.pop()
# print(l)


# l = [23, 33, 43, 23, 53, 64, 23]
# l.pop(3)
# print(l)


# l = [23, 33, 43, 23, 53, 64, 23]
# l.pop(90)
# print(l)
