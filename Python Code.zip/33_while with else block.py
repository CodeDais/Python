#While with else block 

i=1
while i<=10:
    if i==6:
        break
    print(i)
    i=i+1
else:
    print('This is else block')