# # print number from 1 to 5 using recursion

# def fun(num):
#     if num == 6:
#         return
#     else:
#         print(num)
#         fun(num+1)


# fun(1)


# def fun(num):
#     if num == 3:
#         return
#     else:
#         fun(num+1)
#         print(num)


# fun(1)

