def fun(*a):
    print(a)


t = (99, 88, 77)
fun(10, 20, *t)
