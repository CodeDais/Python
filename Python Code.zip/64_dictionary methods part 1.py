# list methods
# get()
# d = {23: 'surendra', 24: 'priyanka', 25: 'rahul', 26: 'zini'}
# print(d.get(23))
# print(d.get(25))


# print(d.get(999))
# print(d[23])
# print(d[999])

# print(d.get(999))

# print(d.get(999, 'unknown'))

# print(d.get(23, 'unknown'))


# items()

# d = {23: 'surendra', 24: 'priyanka', 25: 'rahul', 26: 'zini'}

# print(d.items())


# d = {23: 'surendra', 24: 'priyanka', 25: 'rahul', 26: 'zini'}

# for i in d.items():
#     print(i)


# d = {23: 'surendra', 24: 'priyanka', 25: 'rahul', 26: 'zini'}

# for i, j in d.items():
#     print(i, '   ', j)


# d = {23: 'surendra', 24: 'priyanka', 25: 'rahul', 26: 'zini'}

# for k, v in d.items():
#     print(k, '   ', v)

# pop()

# d = {23: 'surendra', 24: 'priyanka', 25: 'rahul', 26: 'zini'}
# print(d)
# print(d.pop(23))
# print(d)

# d = {23: 'surendra', 24: 'priyanka', 25: 'rahul', 26: 'zini'}
# print(d.pop())


# popitem()

# d = {23: 'surendra', 24: 'priyanka', 25: 'rahul', 26: 'zini'}

# print(d.popitem())
# print(d)
