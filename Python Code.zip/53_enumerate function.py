l = [10, 20, 30, 40, 50]

for i, j in enumerate(l):
    print(i, " ", j)
