#   * and ** in function call

# def fun(a, x, y, z):
#     print(a)
#     print(x)
#     print(y)
#     print(z)


# fun(10, 20, 30, 40)


# def fun(a, x, y, z):
#     print(a)
#     print(x)
#     print(y)
#     print(z)


# l = [10, 20, 30, 40]

# fun(*l)


# def fun(a, x, y, z):
#     print(a)
#     print(x)
#     print(y)
#     print(z)


# l = [10, 20, 30]

# fun(*l)


# def fun(a, x, y, z):
#     print(a)
#     print(x)
#     print(y)
#     print(z)


# l = [10, 20, 30]

# fun(*l, 777)


# def fun(a, x, y, z):
#     print(a)
#     print(x)
#     print(y)
#     print(z)


# l = [10, 20, 30]

# fun(777, *l)


# def fun(a, x, y, z):
#     print(a)
#     print(x)
#     print(y)
#     print(z)


# l = [10, 20]

# fun(777, *l)


# def fun(a, x, y, z):
#     print(a)
#     print(x)
#     print(y)
#     print(z)


# l = [10, 20]

# fun(777, 888, *l)


# def fun(a, x, y, z):
#     print(a)
#     print(x)
#     print(y)
#     print(z)


# l = [10, 20, 30]

# fun(777, 888, *l)


# def fun(a, x, y, z):
#     print(a)
#     print(x)
#     print(y)
#     print(z)


# t = (10, 20, 30, 40)

# fun(*t)


# def fun(a, x, y, z):
#     print(a)
#     print(x)
#     print(y)
#     print(z)


# s = {10, 20, 30, 40}

# fun(*s)


# ** in function call

# def fun(a, **s):
#     print(a)
#     print(s)


# fun(10, i=100)


# def fun(a, **s):
#     print(a)
#     print(s)


# d = {'i': 100, 'j': 200, 'k': 300}
# fun(10, **d)


# def fun(a, **s):
#     print(a)
#     print(s)


# d = {'i': 100, 'j': 200, 'k': 300}
# fun(10, i=100,j=200,k=300)
