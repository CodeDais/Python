# msg='welcome to python'
# print(msg)

# msg="welcome to pythongfdghjqe"
# print(msg)

# msg='''this is 
# python 
# class
# '''
# print(msg)

# address='''Lane-2
# Khandagiri
# BBSR
# Odisha
# '''

# print(address)


# address="""Lane-2
# Khandagiri
# BBSR
# Odisha
# India
# """

# print(address)


# s1="wlcome to 'python' programming"
# print(s1)

# s1='wlcome to "python programming'
# print(s1)


msg="welcome to python"
print(type(msg))
# print(msg[5])
# print(msg[2])
# print(msg[16])
# print(msg[-1])
# print(msg[500])
# print(msg[-200])