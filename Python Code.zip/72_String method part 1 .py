# s = "hello python programming language"
# print(s.startswith('hello'))
# print(s.startswith('Hello'))
# print(s.endswith('language'))
# print(s.endswith('abc'))

# s = "hello python programming language"
# print(s.isalpha())

# s = "hellopythonprogramminglanguage"
# print(s.isalpha())

# s = "Hellopython"
# print(s.isalpha())

# s = "1Hellopython"
# print(s.isalpha())


# s = "1Hellopython"
# print(s.isalnum())

# s = "1111"
# print(s.isalnum())

# s = "1*2"
# print(s.isalnum())

# s = "123"
# print(s.isdigit())

# s = "123hello"
# print(s.isdigit())

# s = "123hello"
# print(s.islower())

# s = "123hEllo"
# print(s.islower())

# s = "hEllo"
# print(s.isupper())


# s = "ABC"
# print(s.isupper())


# s = "Surendra"
# print(s.istitle())


# s = "sURENDRA"
# print(s.istitle())


# s = "     "
# print(s.isspace())


# s = "   .  "
# print(s.isspace())


# s = "Hello Python langauge"
# print(s.upper())
# print(s)


# s = "Hello Python langauge"
# s1 = s.upper()
# print(s)
# print(s1)

# print(id(s))
# print(id(s1))

# s = "Hello Python langauge"
# print(s.lower())


# s = "Hello Python langauge"
# print(s.swapcase())


# s = "Hello Python langauge"
# print(s.title())


# s = "Hello Python langauge"
# print(s.capitalize())

# s = "Hello Python langauge"
# print(len(s))


# s = "Hello Python langauge"
# print(s.count('a'))


# s = "Hello Python langauge"
# print(s.count('a', 16))


s = 'python is bad programming'
print(s.replace('bad', 'good'))
print(s)
