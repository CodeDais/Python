# creations of set in diff way
# creation of empty set
# s = {}
# print(s)
# print(type(s))

# way of creating empty set using set()
# s = set()
# print(s)
# print(type(s))

# # creation of set with multiple elements
# s = {23, 33, 43, 53, 63}
# print(s)
# print(type(s))


# creation of set with heterognous elements
# s = {23, 33, 43, 53, 63, 'surendra', 4.5, True}
# print(s)
# print(type(s))

# crations of set using set()
# craetion of set from list
# l = [23, 33, 43, 53, 63]
# s = set(l)
# print(s)
# print(type(s))

# craetion of set from tuple
# t = (23, 33, 43, 53, 63)
# s = set(t)
# print(s)
# print(type(s))

# creation of set from range()
# s=set(range(10))
# print(s)
# print(type(s))

# creation of set from str
# name = "surendra kumar panda"
# s = set(name)
# print(s)
# print(type(s))


# name = "surendra kumar panda"
# s = set(name.split())
# print(s)
# print(type(s))


# s = set("surendra kumar panda")
# print(s)
# print(type(s))

# s = {23, 33, 43, 53, 63}
# print(s[2])
# print(s[::])

# in and not in

# s = {23, 33, 'surendra', 'rahul', 43, 53, 63}
# print('surendra' in s)
# print('priyanka' in s)
# print('surendra' not in s)
# print('priyanka' not in s)
