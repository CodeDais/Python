# num=int(input('Enter a number'))

# if num%2==0:
#     print('Number is Even')
# else:
#     print('Number is Odd')