# a=10
# b=25
# print(a>b)
# print(a<b) 

# a=1
# b=10
# print(a>=b)


# a=10
# b=10
# print(a<=b)

# we can also apply realtional opeartor for str datatype 

# a='aaa'
# b='bbb'
# print(a>b)  # aaa>bbb
# print(a<b)


# name='surendra'
# name1='surendra'
# print(name>name1)
# print(name<name1)
# print(name<=name1)
# print(name>=name1)


# print(10<20<30<40)
# print(10<20<50<40)

# print(100>'rahul')
# print(True>True)
# print(True>False) # 1>0
# print(False>True)

# equality  ==  !=

# print(10==10)
# print(100==10)
# print(100!=10)
# print(10==10==10==10)
# print(10==10==11==10)
# print('surendra'=='surendra')
# print(10=='surendra')

