# c=50+60j
# print(type(c))
# print(c)

# c=45.69+60j
# print(c)

# c=45.69+88.96j
# print(c)

# in real part ----> binary / oct/dec /hexa
#img ---> dec

# c=0b1111+10j
# print(c)


# c=0o6542+8j
# print(c)

# c=0x6545abc+7j
# print(c)

# c=50+0b1111j
# print(c)

# a=10+20j
# b=60+25j
# c=a+b
# print(c)
# print(type(c))


# a=10+20j
# print(a.real)
# print(a.imag)

# c=10.66+23k  # error
# print(c)


# c=105j+200j  
# print(type(c))
# print(c)


c=105J+200j
print(type(c))
print(c)