num=int(input('enter a number'))

if num==0:
    print('Number is Zero')
elif num>0:
    print('Number is Positive')
else:
    print('Number is negative')