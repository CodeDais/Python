# cgpa=9.26
# print(type(cgpa))
# print(cgpa)

# empSal=2.2e450
# print(empSal)

# f=1234_234.56_456789
# print(f)

# f=0b1111.10
# print(f)

# f=0o456.13
# print(f)

# f=0x4589a6.13
# print(f)

# f=505050.60
# print(f)