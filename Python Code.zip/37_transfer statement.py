# break continue pass
# how to exit from the loop - break

# for i in range(10):
#     if i == 7:
#         break
#     print(i)


# continue - skip
# 0 1 2 3 4 5 6 7 8 9

# for i in range(10):
#     if i == 5 or i==8:
#         continue
#     print(i)


# for i in range(10):
#     if i == 55:
#         continue
#     print(i)


# pass - empty statemnet
# if u want to provide empty body then gofor pass statemnet
# don nothing

# for i in range(10):
#     if i % 2 == 0:
#         pass
#     else:
#         print(i)

# def f1():pass
