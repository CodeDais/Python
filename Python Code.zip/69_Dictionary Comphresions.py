# Dictionary Comprehensions

from cmath import pi


# d={i for i in range(1,6)}
# print(d)
# print(type(d))


# d={i:i for i in range(1,6)}
# print(d)
# print(type(d))

# d={i:i*i for i in range(1,6)}
# print(d)
# print(type(d))

# d={i:i*i for i in range(1,6)}
# print(d)
# print(type(d))

# working with list to create dict 

# l=[2.3,4.2,5.6,7.8]
# d={r:3.14*r*r for r in l}
# print(d)


# names=['surendra','priyanka','rahul','zini']
# d={i:len(i) for i in names}
# print(d)

#
# names=['surendra','priyanka','rahul','zini']
# d={i:len(i) for i in names if len(i)>6}
# print(d)

