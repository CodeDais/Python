def add(a, b):
    print('mod 1 : ', a+b)


if __name__ == '__main__':
    add(23, 24)
