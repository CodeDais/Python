#break statement 

i=1
while i<=10:
    print(i)
    if i==5:
        break
    
    i=i+1