l = ['Hi', 'Hello']
s = ['Surendra', 'Priyanka', 'Rahul', 'Zini']
new_List = []

for i in l:
    for j in s:
        new_List.append(i+' '+j)


print(new_List)
