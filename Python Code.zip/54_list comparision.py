# l = ['surendra', 'priyanka', 'rahul', 'zini']
# s = ['Surendra', 'Priyanka', 'Rahul', 'zini']
# p = ['surendra', 'priyanka', 'rahul', 'zini']

# print(l == s)
# print(l == p)


# l = [10, 20, 30]
# s = [20, 10, 30]
# print(l == s)


# a = [8, 20, 30]
# b = [1]

# print(a > b)
