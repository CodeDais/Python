l = []
print('press -1 for stop ')

while True:
    data = int(input())
    if data == -1:
        break
    else:
        l.append(data)

print(l)
