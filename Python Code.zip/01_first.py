# print('Hello Welcome to Python')
# a=10
# b=20
# c=a+b
# print(c)

# name='surendra'
# print(name)

# name="surendra panda"
# print(name)

# name="""surendra panda"""
# print(name)

# name='''surendra 
# kumar 
# pandafdf'''
# print(name)

name='priyanka'
print(name[0])
print(name[1])
print(name[20])