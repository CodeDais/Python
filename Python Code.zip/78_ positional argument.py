# def fun(a, b, c):
#     print(a, b, c)


# # fun(10, 20, 30)
# # fun(10, 20)  # fun() missing 1 required positional argument: 'c'

# # fun(10)  # fun() missing 2 required positional arguments: 'b' and 'c

# # fun()  # TypeError: fun() missing 3 required positional arguments: 'a', 'b', and 'c'

# # fun([10, 20, 30])  # fun([10, 20, 30])
# # TypeError: fun() missing 2 required positional arguments: 'b' and 'c'


# # fun([10, 20, 30], [10, 20], [90])  # [10, 20, 30] [10, 20] [9

# # fun((), [], {})


# def fun():
#     print('hello python ! how r u ?')


# fun()
# fun(10)  # TypeError: fun() takes 0 positional arguments but 1 was given

# fun(10, 20)  # TypeError: fun() takes 0 positional arguments but 2 were given

# fun(None)

# fun(0)  # TypeError: fun() takes 0 positional arguments but 1 was given

# fun(False)  # TypeError: fun() takes 0 positional arguments but 1 was given
