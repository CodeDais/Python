l = [23, 33, 43, 53, 64]
n = len(l)
for i in range(n):
    print("{} is present at index {} / {} ".format(l[i], i, i-n))
