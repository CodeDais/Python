def add(a, b):
    print(a+b)


if __name__ == '__main__':
    add(10, 20)
else:
    print('md1 executed indirectly')
