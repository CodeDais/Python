# Unary Minus Operator (-)
# num=15
# print(-num)

num=-145
num=-num
print(num)