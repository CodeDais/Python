# a=True
# print(type(a))
# print(a)

# a=False
# print(type(a))
# print(a)

# a=90
# b=150
# result=a>b
# print(result)

# a=90
# b=150
# result=a<b
# print(result)

# a=90
# b=90
# result=a<b
# print(result)

# print(True+True+True+True)
# print(True+True+True+False)
# print(True*True)
# print(True-True)
# print(True/True)

a=True 
print(a)