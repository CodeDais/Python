a=500
b=600

def sub(x,y):
    print(f'i m from data module sub is {x-y}')

def mul(x,y):
    print(f'i m from data module mul is {x*y}')