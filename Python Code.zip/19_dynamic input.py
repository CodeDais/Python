#Dynamic Input 

# a=41
# b=19
# c=a+b
# print(c)


# a=int(input('enter a value'))
# b=int(input('enter b value'))
# c=a+b
# print(c)

username=input('enter u r name ')
print(username)
print(type(username))