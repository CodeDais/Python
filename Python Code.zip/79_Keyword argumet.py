# def cal(a, b, c):
#     print(a+b*c)

# cal(a=5, b=6, c=7)  # 47
# cal(5,6,c=7)
# cal(5, b=6, c=7)
# cal(5, c=6, b=7)
# cal(5, a=6, b=7)  # TypeError: cal() got multiple values for argument 'a'
# cal(5, 6, b=7)  # TypeError: cal() got multiple values for argument 'b'

# cal(5, b=6, 8)  # positional argument follows keyword argument

# cal(5, b=6, c=7)
# cal(5, 6, 7)
# # cal(6, 5, 7)  # this is an issues with positinal argumnet

# # cal(b=6, a=5, c=7)

# # cal(a=5, b=6, c=7)

# # cal(b=6, c=7,a=5) # here order is not important


# positional argumnet and keyword argumnet

# def cal(a, b, c):
#     print(a+b*c)

# cal(6,a


# def cal(a, b, c, d, e, f):
#     print(a+b*c)


# # cal(6, 7, 8, e=9, 10, 11)
# cal(6, 7, f=8, 10, 11, a=9)


# def cal(b, c, d, e, f, a):
#     print(a+b*c)


# # cal(6, 7, 8, e=9, 10, 11)
# cal(6, 7, 10, 11, a=9, f=8)
