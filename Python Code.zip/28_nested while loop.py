# i=1
# while i<=3 :
#     print('hello')
#     j=1
#     while j<=3:
#         print('Priyanka')
#         j=j+1
#     i=i+1

# i=1
# while i<=5 :
#     print('i =     ',i)
#     j=1
#     while j<=10:
#         print('j = ',j)
#         j=j+1
#     i=i+1
















# i=1
# while i<=10:
#   j=1
#   while j<=10:
#         print (i,"*",j,'=',i*j)
#         j=j+1
#   i=i+1
#   print('')

#while else 



i=1
while i<=5:
    print(i)
    if i==3:
        break
    i=i+1
    
else:
    print('while loop executed successfully- else block is executing')



# var = 10                    
# while var > 0:              
#    var = var -1
#    if var == 5:
#       continue
#    print ('Current variable value :', var)
# print ("Good bye!")

i=0
while i<10:
    i=i+1
    if i==5 or i==7:
        continue
    print(i)
