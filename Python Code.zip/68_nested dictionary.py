#Nested Dictionary (inner dictionary)
# d={1:{'name':'surendra'},2:{'name':'priyanka'},3:{'name':'rahul'},4:{'name':'zini'}}
# print(d)

# for i in d:
#     print(i)

# for i in d.values():
#     print(i)

# for i,j in d.items():
#     print(i,j)

# print(d[1])

# print(d[1]['name'])


# d={1:{'name':'surendra'},2:{'name':'priyanka'},3:{6:{7:{8:9}}}}

# print(d[3])
# print(d[3][6])
# print(d[3][6][7])
# print(d[3][6][7][8])


# d={1:{'name':'surendra'},2:{'name':'priyanka'},3:{6:{7:{8:9}}}}


# d[3][6][7][8]=5000
# print(d[3][6][7][8])

# print(d)