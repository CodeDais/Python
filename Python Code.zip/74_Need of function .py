# check the number is even or odd (without using function)
# a = 10
# if a % 2 == 0:
#     print('even')
# else:
#     print('odd')

# b = 20
# if b % 2 == 0:
#     print('even')
# else:
#     print('odd')


# c = 89
# if c % 2 == 0:
#     print('even')
# else:
#     print('odd')


# d = 90
# if d % 2 == 0:
#     print('even')
# else:
#     print('odd')


# e = 1023
# if e % 2 == 0:
#     print('even')
# else:
#     print('odd')


# check a number is even or odd using funtion

def evenodd(num):
    if num % 2 == 0:
        print('even')
    else:
        print('odd')

evenodd(10)
evenodd(20)
evenodd(89)
evenodd(90)
evenodd(1023)
