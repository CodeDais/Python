# a=90
# print(type(a))

# x=-900
# print(type(x))

#conver decimal 15 to bin
# print(bin(15))

#convet octal to bin

# print(bin(0o156))

# Decimal to octal 
# print(oct(50))
# binary to octal 
# print(oct(0b111))

#decimal to hexadecimal
# print(hex(100))

#oct to hexadecimal
# print(hex(0o555))