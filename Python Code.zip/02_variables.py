# a=90
# print(a)
# print(a*2)
# print(a/2)

#how to add two numbers

# num1=50
# num2=100
# result=num1+num2
# print(result)

# num1=90
# print(num1)

# num1=100
# print(num1)

# num1=10
# print(num1)


# abc190=5000
# print(abc190)


# abc_190=5000
# print(abc_190)

# abc@190=5000
# print(abc@190)

# cash=500
# print(cash)

# ca$h=500
# print(ca$h)



# abc1234=5000
# print(abc1234)

# 1234abc=5000
# print(1234abc)


# if=90
# print(if)


# If=900
# print(If)