i in # for loop

# for i in range(10):
#     print('Surendra')

# for i in range(25):
#     print('Surendra')


# 1 2 3 4 5 6 7 8 9 10

# for i in range(1,11,1):
#     print(i)


# 2 3 4 5 6 7 8 

# for i in range(2,9,1):
#     print(i)


# 200 400 600 800 1000
# for i in range(200,1001,200):
#     print(i)


#10 9 8 7 6 5 4 3 2 1 


# for i in range(10,0,-1):
#     print(i)


# 999 777 555 333 111

# for i in range(999,110,-222):
#     print(i)

# print all even number from 100 to 120 
# for i in range(100,121,1):
#     if i%2==0:
#         print(i)


# for i in range(100,121,2):
#     print(i)


# name="888888"

# for i in name:
#     print(i)


# name="bhgdfhew"

# for i in name:
#     print(i)



# name ='priyanka'
# for i in name:
#     print(i,end="-")

fact=1
for i in range(1,6):
    fact=fact*i

print(fact)