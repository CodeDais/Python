# print my name 10 time 
# i=1
# while i<=10:
#     print('Surendra')
#     i=i+1
    
# i=1
# while i<=20:
#     print('Surendra')
#     i=i+1
    

# # 1- 10 
# i=1
# while i<=10:
#     print(i)
#     i=i+1
    


# # 111- 120 
# i=111
# while i<=120:
#     print(i)
#     i=i+1
    

# 10- 1 
# i=10
# while i>=1:
#     print(i)
#     i=i-1
    
# # 111 222  333  444  555

# i=111
# while i<=555:
#     print(i)
#     i=i+111


# # 999 777 555 333
# i=999
# while i>=333:
#     print(i)
#     i=i-222

# print * 10 time 

# i=1
# while i<=10:
#     print('*')
#     i=i+1

# i=1
# while i<=10:
#     print('8',end=' ')
#     i=i+1


# 1 2 3 4 5 6 7 8 9 10

# i=1
# while i<=10:
#     print(i,end=' ')
#     i=i+1


