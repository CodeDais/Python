# num=int(input('enter a number'))
# i=1
# while i<=10:
#     print(num,' *' ,i,' = ',num*i)
#     i=i+1


# num=int(input('enter a number'))
# i=1
# while i<=10:
#     print(f'{num} * {i} = {num*i}')
#     i=i+1
